import CONFIG from './config.js';

console.log("Background script loaded!");

// Add supported languages constant at the top
const SUPPORTED_LANGUAGES = {
    'en': 'English',
    'es': 'Spanish',
    'hi': 'Hindi',
    'hi-en': 'Hinglish', // Add Hinglish
    'fr': 'French',
    'de': 'German',
    // Easy to add more languages:
    // 'bn': 'Bengali',
    // 'ar': 'Arabic',
    // 'zh': 'Chinese',
    // etc.
};

// Add connection monitoring
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "PING") {
        sendResponse({ status: 'ok' });
        return false;
    }
    
    if (request.type === "WORD_CLICKED" || request.type === "REGENERATE") {
        // Pass targetLanguage from request to getWordData
        getWordData(request.word, request.context, request.type === "REGENERATE", request.targetLanguage)
            .then(data => sendResponse({ data }))
            .catch(error => {
                console.error('API Error:', error);
                sendResponse({ error: error.message });
            });
        return true; // Keep connection open for async response
    }

    if (request.type === "TRANSLATE_DEFINITION") {
        translateDefinition(request)
            .then(data => sendResponse({ data }))
            .catch(error => {
                console.error('Translation error:', error);
                sendResponse({ error: error.message });
            });
        return true;
    }

    return false;
});

// Store original responses
const wordResponses = new Map();

// Add response history tracking
const responseHistory = new Map(); // Store history of responses for each word

// Add language-specific error messages
const ERROR_MESSAGES = {
    'en': {
        definition: 'Definition temporarily unavailable',
    },
    'hi': {
        definition: 'परिभाषा अस्थायी रूप से उपलब्ध नहीं है',
    },
    'es': {
        definition: 'Definición temporalmente no disponible',
    },
    'fr': {
        definition: 'Définition temporairement indisponible',
    },
    'de': {
        definition: 'Definition vorübergehend nicht verfügbar',
    },
    'hi-en': {
        definition: 'Definition abhi available nahi hai',
    },
};

// Update translation prompts to enforce conciseness
const LANGUAGE_PROMPTS = {
    'en': 'GIVE BRIEF ENGLISH RESPONSE:',
    'es': 'DA UNA RESPUESTA BREVE EN ESPAÑOL:',
    'hi': 'संक्षिप्त हिंदी उत्तर दें:',
    'fr': 'DONNEZ UNE RÉPONSE COURTE EN FRANÇAIS:',
    'de': 'GEBEN SIE EINE KURZE ANTWORT AUF DEUTSCH:',
    'hi-en': 'GIVE BRIEF HINGLISH RESPONSE (mix Hindi and English):'
};

// Add improved script detection helper
function detectScriptLanguage(text) {
    // More accurate script detection
    if (/[ -]/.test(text)) return 'en'; // Basic Latin
    if (/[-]/.test(text)) return 'hi'; // Devanagari
    if (/[áéíóúñü¿¡]/.test(text)) return 'es';      // Spanish
    if (/[àâçéèêëîïôûùüÿœæ]/.test(text)) return 'fr'; // French
    if (/[äöüßẞ]/.test(text)) return 'de';          // German
    if (/^[a-zA-Z\s]+$/.test(text)) return 'en';    // English
    // Example for adding more scripts:
    // if (/[\u0980-\u09FF]/.test(text)) return 'bn';  // Bengali
    // if (/[\u0600-\u06FF]/.test(text)) return 'ar';  // Arabic
    // if (/[\u4E00-\u9FFF]/.test(text)) return 'zh';  // Chinese
    return null;
}

// Add caching system
const cache = {
    definitions: new Map(),
    MAX_CACHE_SIZE: 100
};

// Add performance optimization
const optimizePrompt = (text) => text.replace(/\s+/g, ' ').trim().slice(0, 1000);

// Modify getWordData function to accept targetLanguage parameter
async function getWordData(word, contextData, isRegenerate = false, targetLanguage = null) {
    try {
        // Check cache first
        const cacheKey = `${word}-${targetLanguage || 'default'}`;
        if (!isRegenerate && cache.definitions.has(cacheKey)) {
            return cache.definitions.get(cacheKey);
        }

        // Improve context parsing with better error handling
        let context;
        try {
            context = typeof contextData === 'string' ? 
                JSON.parse(contextData.replace(/[\u0000-\u001F]+/g, ' ').trim()) : 
                contextData;
        } catch (parseError) {
            console.warn('Context parsing failed, using fallback:', parseError);
            context = {
                sentences: typeof contextData === 'string' ? contextData : word,
                structure: '',
                position: 0.5
            };
        }

        // Ensure context is properly formatted
        context = {
            sentences: context.sentences?.toString().replace(/[\u0000-\u001F]+/g, ' ').trim() || word,
            structure: context.structure?.toString().trim() || '',
            position: typeof context.position === 'number' ? context.position : 0.5
        };

        // Detect language from the word itself first
        const scriptLanguage = detectScriptLanguage(word);
        let detectedLanguage = scriptLanguage;

        // Only use API for language detection if script detection fails
        if (!scriptLanguage) {
            // Existing language detection code
            const detectPrompt = `DETECT LANGUAGE CODE (en/es/hi/fr/de):
                "${word}"
                RESPOND WITH SINGLE CODE ONLY.
            `;

            const detectResponse = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${CONFIG.API_KEY}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{ parts: [{ text: detectPrompt }] }],
                        generationConfig: { temperature: 0.1, maxOutputTokens: 10 }
                    })
                }
            );
            
            const detectData = await detectResponse.json();
            detectedLanguage = detectData?.candidates?.[0]?.content?.parts?.[0]?.text.trim().toLowerCase() || 'en';
        }

        // If translating to a different language, keep track of source
        const sourceLanguage = detectedLanguage;
        
        // Use source language if no target specified
        const responseLanguage = targetLanguage || sourceLanguage;

        // Get meaning in source language first if translating
        let originalMeaning = '';
        if (targetLanguage && targetLanguage !== detectedLanguage) {
            const originalPrompt = `
                EXPLAIN THIS WORD IN ${detectedLanguage}:
                WORD: "${word}"
                CONTEXT: "${context.sentences}"
                RESPOND WITH A BRIEF EXPLANATION ONLY.
            `;

            const originalResponse = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${CONFIG.API_KEY}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{ parts: [{ text: originalPrompt }] }],
                        generationConfig: { temperature: 0.1, maxOutputTokens: 100 }
                    })
                }
            );

            const originalData = await originalResponse.json();
            originalMeaning = originalData?.candidates?.[0]?.content?.parts?.[0]?.text.trim();
        }

        // Updated translation prompt to respect source language
        const translationPrompt = isRegenerate ? 
            `GENERATE NEW RESPONSE IN ${SUPPORTED_LANGUAGES[targetLanguage]}:
            WORD: "${word}"
            CONTEXT: "${context.sentences}"

            REQUIREMENTS:
            1. Give a FRESH perspective in ${SUPPORTED_LANGUAGES[targetLanguage]}
            2. Keep context but provide new insights
            3. Definition: 20-25 words, clear and natural

            FORMAT:
            DEFINITION: (fresh explanation in ${targetLanguage})

            IMPORTANT:
            - Must be DIFFERENT from previous response
            - Natural language in ${SUPPORTED_LANGUAGES[targetLanguage]}
            - Maintain context accuracy
        `.trim() : 
        `TASK: EXPLAIN IN ${SUPPORTED_LANGUAGES[responseLanguage].toUpperCase()}
            WORD: "${word}"
            CONTEXT: "${context.sentences}"
            ORIGINAL LANGUAGE: ${SUPPORTED_LANGUAGES[sourceLanguage]}

            REQUIREMENTS:
            1. RESPOND ENTIRELY IN ${SUPPORTED_LANGUAGES[responseLanguage].toUpperCase()}
            2. Use appropriate script for the language
            3. Give a clear, natural definition in 20-25 words

            FORMAT:
            DEFINITION: (explain in ${responseLanguage})
        `.trim();

        // Stricter API parameters for more focused responses
        const apiParams = {
            temperature: isRegenerate ? 0.7 : 0.1, // Higher temperature for regeneration
            maxOutputTokens: 150, // Reduced from 250
            topP: 0.7,
            topK: 10
        };

        // Optimized API call
        const response = await fetchWithTimeout(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${CONFIG.API_KEY}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: translationPrompt }] }],
                    generationConfig: apiParams
                })
            },
            5000 // 5 second timeout
        );

        const data = await response.json();
        if (!data?.candidates?.[0]?.content?.parts?.[0]?.text) {
            throw new Error('Empty translation response');
        }

        // Extract sections with stricter validation
        const text = data.candidates[0].content.parts[0].text.trim();
        const definitionMatch = text.match(/DEFINITION:?\s*([^]*)/i);
        const definition = definitionMatch ? definitionMatch[1].trim() : text;

        const result = {
            definition: definition,
            isPhrase: word.includes(' '),
            detectedLanguage: detectedLanguage,
            sourceLanguage: sourceLanguage,
            currentLanguage: responseLanguage,
            originalWord: word,
            contextPreserved: true
        };

        // Cache the result
        if (!isRegenerate) {
            cache.definitions.set(cacheKey, result);
            // Cleanup old cache entries
            if (cache.definitions.size > cache.MAX_CACHE_SIZE) {
                const firstKey = cache.definitions.keys().next().value;
                cache.definitions.delete(firstKey);
            }
        }

        return result;

    } catch (error) {
        console.error('Translation error:', error);
        
        if (!isRegenerate) {
            try {
                return await getWordData(word, contextData, true, targetLanguage);
            } catch (retryError) {
                console.error('Translation retry failed:', retryError);
            }
        }

        // Return error messages in target language
        const messages = ERROR_MESSAGES[targetLanguage || 'en'];
        return {
            definition: messages.definition,
            isPhrase: word.includes(' '),
            detectedLanguage: detectedLanguage || 'en',
            currentLanguage: targetLanguage || 'en',
            originalWord: word,
            error: true
        };
    }
}

// Add timeout to fetch
async function fetchWithTimeout(url, options, timeout) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(id);
        return response;
    } catch (error) {
        clearTimeout(id);
        throw error;
    }
}

// Add context optimization
async function optimizeContext(contextData) {
    try {
        const context = typeof contextData === 'string' ? 
            JSON.parse(contextData) : contextData;

        return {
            sentences: context.sentences?.slice(0, 200) || '',
            structure: context.structure?.slice(0, 100) || '',
            position: context.position || 0.5
        };
    } catch (error) {
        return {
            sentences: String(contextData).slice(0, 200),
            structure: '',
            position: 0.5
        };
    }
}

// Add new function to handle definition translation
async function translateDefinition(request) {
    const promptTemplate = `
        COMPLETE TRANSLATION TASK IN ${SUPPORTED_LANGUAGES[request.targetLanguage]}:

        SELECTED WORD: "${request.word}"
        CONTEXT: "${request.context}"

        SOURCE CONTENT TO TRANSLATE:
        DEFINITION: "${request.originalDefinition}"

        MANDATORY REQUIREMENTS:
        1. TRANSLATE EVERYTHING TO ${SUPPORTED_LANGUAGES[request.targetLanguage]}
        2. Keep proper script (Devanagari for Hindi, Latin for Spanish etc.)
        3. Maintain natural language flow
        4. Keep same structure and format
        5. Translate ALL sections (definition)

        RESPOND STRICTLY IN THIS FORMAT:
        DEFINITION: (translated definition)

        IMPORTANT NOTES:
        - Translate examples completely
        - Use natural expressions in target language
        - NO English or untranslated words (except proper nouns)
    `.trim();

    try {
        const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${CONFIG.API_KEY}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: promptTemplate }] }],
                    generationConfig: {
                        temperature: 0.1,
                        maxOutputTokens: 500,
                        topP: 0.8,
                        topK: 20
                    }
                })
            }
        );

        const data = await response.json();
        const text = data.candidates[0].content.parts[0].text.trim();

        // Enhanced section extraction with validation
        const definition = text.match(/DEFINITION:?\s*([^]*)/i)?.[1]?.trim() || '';

        // Validation to ensure all sections are translated
        if (!definition) {
            throw new Error('Incomplete translation');
        }

        return {
            definition,
            detectedLanguage: request.targetLanguage,
            currentLanguage: request.targetLanguage,
            originalWord: request.word,
            isTranslated: true
        };

    } catch (error) {
        console.error('Translation error:', error);
        // Return error in target language
        const messages = ERROR_MESSAGES[request.targetLanguage];
        return {
            definition: messages.definition,
            detectedLanguage: request.targetLanguage,
            currentLanguage: request.targetLanguage,
            originalWord: request.word,
            error: true
        };
    }
}

// Add connection status tracking
let activeConnections = new Set();

// Update message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Add tab to active connections when any message is received
    if (sender.tab) {
        activeConnections.add(sender.tab.id);
    }

    if (request.type === "PING") {
        sendResponse({ status: 'ok' });
        return false;
    }

    if (request.type === "WORD_CLICKED" || request.type === "REGENERATE") {
        // Pass targetLanguage from request to getWordData
        getWordData(request.word, request.context, request.type === "REGENERATE", request.targetLanguage)
            .then(data => sendResponse({ data }))
            .catch(error => {
                console.error('API Error:', error);
                sendResponse({ error: error.message });
            });
        return true; // Keep connection open for async response
    }

    if (request.type === "TRANSLATE_DEFINITION") {
        translateDefinition(request)
            .then(data => sendResponse({ data }))
            .catch(error => {
                console.error('Translation error:', error);
                sendResponse({ error: error.message });
            });
        return true;
    }

    return false;
});

// Handle tab cleanup
chrome.tabs.onRemoved.addListener((tabId) => {
    activeConnections.delete(tabId);
});

// Handle tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'complete') {
        // Tab was reloaded/updated
        activeConnections.delete(tabId);
    }
});

// Add connection management
let ports = new Set();

// Keep track of active tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        chrome.tabs.sendMessage(tabId, { type: "TAB_READY" })
            .catch(() => {}); // Ignore errors for inactive tabs
    }
});

// Handle port connections
chrome.runtime.onConnect.addListener(port => {
    if (port.name === 'keepAlive') {
        ports.add(port);
        port.onDisconnect.addListener(() => {
            ports.delete(port);
        });
    }
});

// Add automatic recovery
setInterval(() => {
    chrome.tabs.query({ active: true }, tabs => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, { type: "PING" })
                .catch(() => {
                    // Try to reload content script if it's not responding
                    chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['src/contentScript.js']
                    }).catch(() => {});
                });
        });
    });
}, 30000); // Check every 30 seconds

// Add service worker keep-alive
let keepAliveInterval;

// Keep service worker active
function keepServiceWorkerAlive() {
    keepAliveInterval = setInterval(() => {
        chrome.runtime.getPlatformInfo(() => {
            chrome.runtime.lastError; // Clear any error
        });
    }, 20000); // Ping every 20 seconds
}

// Initialize keep-alive on startup
keepServiceWorkerAlive();

// Handle service worker activation
chrome.runtime.onStartup.addListener(keepServiceWorkerAlive);
chrome.runtime.onInstalled.addListener(keepServiceWorkerAlive);

// Cleanup on shutdown
chrome.runtime.onSuspend.addListener(() => {
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
    }
});

// Add tab activation monitoring
chrome.tabs.onActivated.addListener(async (activeInfo) => {
    try {
        await chrome.tabs.sendMessage(activeInfo.tabId, { type: "TAB_ACTIVATED" });
    } catch (error) {
        // If content script isn't ready, reload it
        try {
            await chrome.scripting.executeScript({
                target: { tabId: activeInfo.tabId },
                files: ['src/contentScript.js']
            });
        } catch (e) {
            console.warn('Tab activation handling failed:', e);
        }
    }
});

// Improve tab update handling
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Send ready message after a short delay to ensure content script is loaded
        setTimeout(() => {
            chrome.tabs.sendMessage(tabId, { type: "TAB_READY" })
                .catch(() => {
                    // If content script isn't responding, reload it
                    chrome.scripting.executeScript({
                        target: { tabId },
                        files: ['src/contentScript.js']
                    }).catch(() => {});
                });
        }, 500);
    }
});

// Add automatic recovery check
setInterval(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        if (tabs[0]) {
            try {
                await chrome.tabs.sendMessage(tabs[0].id, { type: "PING" });
            } catch (error) {
                // If ping fails, reload content script
                chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    files: ['src/contentScript.js']
                }).catch(() => {});
            }
        }
    });
}, 20000); // Check every 20 seconds