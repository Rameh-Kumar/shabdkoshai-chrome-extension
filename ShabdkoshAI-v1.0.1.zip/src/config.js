const CONFIG = {
    API_KEY: "AIzaSyCL8CZcstREl1_erxnujpcOAHSxsLLws-g",
    MAX_RETRY_ATTEMPTS: 2,
    MAX_SELECTION_LENGTH: 500,
    SUPPORTED_LANGUAGES: {
        'en': 'English',
        'es': 'Spanish',
        'hi': 'Hindi',
        'hi-en': 'Hinglish',
        'fr': 'French',
        'de': 'German'
    }
};

export default CONFIG;
